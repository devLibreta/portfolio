package com.dev.bootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootprojectApplication.class, args);
	}

}
