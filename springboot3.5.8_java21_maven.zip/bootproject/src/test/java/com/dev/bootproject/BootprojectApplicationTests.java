package com.dev.bootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
